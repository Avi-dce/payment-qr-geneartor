# UPI QR Generator (MERN)

Enter a UPI ID (amount optional) → get a scannable UPI payment QR code. Leave the amount blank and the payer types it in their UPI app.

## Run it

Requirements: Node 18+, MongoDB running locally (or an Atlas URI).

```bash
# terminal 1 – API
cd server
cp .env.example .env        # edit MONGO_URI if needed
npm install
npm run dev                 # http://localhost:5000

# terminal 2 – React app
cd client
npm install
npm run dev                 # http://localhost:5173
```

Open http://localhost:5173.

## API

| Method | Route            | Body / purpose                                           |
|--------|------------------|----------------------------------------------------------|
| POST   | /api/qr          | `{ upiId, amount?, payeeName?, note? }` → QR (base64 PNG) |
| GET    | /api/qr/history  | last 20 generated codes                                  |
| GET    | /api/qr/:id      | regenerate a saved code                                  |
| DELETE | /api/qr/:id      | delete a saved code                                      |

## How the QR works

The QR encodes a standard UPI deep link:

`upi://pay?pa=<upi-id>&pn=<name>&am=<amount>&cu=INR&tn=<note>` (`am` is left out when no amount is given)

GPay, PhonePe, Paytm, BHIM etc. read it and open the pay screen with the amount pre-filled.
